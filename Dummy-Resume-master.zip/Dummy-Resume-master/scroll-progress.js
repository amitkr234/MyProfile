// const mainContainer = document.getElementsByTagName("body")[0];
// const progressBar = document.getElementsByClassName("scroll-progress-bar")[0];
// let mainContainerHeight;

// window.onscroll = function () {
// 	mainContainerHeight = mainContainer.offsetHeight - window.innerHeight;
// 	mainContainerPos = mainContainer.getBoundingClientRect();
// 	diff = mainContainerHeight + mainContainerPos.top;
// 	progressPercentage = (diff / mainContainerHeight) * 100;
// 	cssWidth = Math.floor(100.5 - progressPercentage);
// 	console.log(window.innerHeight);
// 	progressBar.style.width = cssWidth + "%";
// };
